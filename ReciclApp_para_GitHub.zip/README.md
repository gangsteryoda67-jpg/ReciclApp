# ReciclApp ♻️

Creadores: Santhiago Toulier, Lautaro Soria y Benjamín Figueroa.

## Estructura
- `web/` — versión web.
- `android/` — proyecto Android WebView.
- `api/analyze.js` — backend seguro para la IA.
- `.github/workflows/build-apk.yml` — genera `ReciclApp.apk`.

## IA
No pongas una API key dentro de `index.html` ni del APK. El backend usa `OPENAI_API_KEY` como variable de entorno.

El frontend tiene `window.RECICLAPP_AI_ENDPOINT`. Para producción debe apuntar a la URL del backend, por ejemplo `https://TU-DOMINIO/api/analyze`.

## APK
En GitHub: Actions → Build ReciclApp APK → Run workflow. Al terminar, descargá el artefacto `ReciclApp-apk`.

## Nota
La versión conserva la interfaz y base de datos de la versión original. La llamada `claude.use(...)` fue reemplazada por una llamada HTTP a un backend seguro.
