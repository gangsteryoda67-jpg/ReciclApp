import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const query = String(req.body?.query || "").trim();
    if (!query) return res.status(400).json({ error: "no es un objeto" });

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      input: `Analiza este objeto para reciclaje: "${query}".
Responde únicamente con JSON válido con estos campos exactos:
nombre, emoji, tipo, donde, grande, reutilizar, co2_g, dato, color.
Usa español rioplatense. Si no es un objeto, devuelve {"error":"no es un objeto"}.`
    });

    let data;
    try {
      data = JSON.parse(response.output_text);
    } catch {
      return res.status(502).json({ error: "no es un objeto" });
    }
    return res.status(200).json(data);
  } catch (e) {
    return res.status(500).json({ error: "no es un objeto" });
  }
}
